/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursionchallenge5;

import java.util.Scanner;

/**
 *
 * @author Benjamin Herzog 
 */
public class RecursionChallenge5 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        String userResponse = "yes";
        do{
        
        System.out.println("Please type a word that has the character 'x' in it.");
        String chooseWord = keyboard.next();
        
        System.out.println("Before recursion: " + chooseWord);
        String after = transform(chooseWord);
        System.out.println("After recursion: " + after); 
        System.out.println(" ");
        
        System.out.println("Would you like to add another word?");
        userResponse = keyboard.next();   
        
    } while(userResponse.equalsIgnoreCase("yes"));
    }
    /**
     * 
     * @param chooseWord
     * @return 
     */
    public static String transform(String chooseWord){
        char x = 'x';
        char y = 'y';
        
        if (chooseWord.length() == 0){
            return chooseWord;
        }
        else if(chooseWord.charAt(0) == 'x'){
            return 'y' + transform(chooseWord.substring(1));
        }
        else {
            return chooseWord.charAt(0) + transform(chooseWord.substring(1));
        }
    }
}